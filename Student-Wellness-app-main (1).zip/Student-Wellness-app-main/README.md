# Student-Wellness-app
A Streamlit app for analyzing student journal entries and tracking wellness
